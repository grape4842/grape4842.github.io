Animated SVG Hero Slider
=========

A full page slider, with animated SVG elements used as transition effects.

[Article on CodyHouse](http://codyhouse.co/gem/animated-svg-hero-slider/)

[Demo](http://codyhouse.co/demo/animated-svg-hero-slider/index.html)

Resources:

-Icons from [Nucleo library](https://nucleoapp.com/)

-[Snap.svg](http://snapsvg.io/) to animate the SVG elements.

-Images from [Unsplash](https://unsplash.com/)
 

[Terms](http://codyhouse.co/terms/)
